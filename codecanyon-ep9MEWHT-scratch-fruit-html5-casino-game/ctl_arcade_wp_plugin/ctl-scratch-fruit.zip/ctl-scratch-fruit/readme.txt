=== CTL Scratch Fruit ===
Tags: casino, casino game, fruit, gratta e vinci, html game, instant win, lottery, poker, scratch, sweepstake
Requires at least: 4.3
Tested up to: 4.3

Add Scratch Fruit to CTL Arcade plugin

== Description ==
Add Scratch Fruit to CTL Arcade plugin